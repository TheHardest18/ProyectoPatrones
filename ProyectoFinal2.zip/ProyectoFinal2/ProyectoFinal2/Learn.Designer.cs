﻿namespace ProyectoFinal2
{
    partial class Learn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Learn));
            this.imgFotos = new System.Windows.Forms.ImageList(this.components);
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.imgFotos2 = new System.Windows.Forms.ImageList(this.components);
            this.imgFotos3 = new System.Windows.Forms.ImageList(this.components);
            this.img4 = new System.Windows.Forms.ImageList(this.components);
            this.btnReproducir1 = new System.Windows.Forms.Button();
            this.listimg1 = new System.Windows.Forms.Label();
            this.listimg4 = new System.Windows.Forms.Label();
            this.listimg3 = new System.Windows.Forms.Label();
            this.listimg2 = new System.Windows.Forms.Label();
            this.btnReproducir2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnModulos = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.txtValidacion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // imgFotos
            // 
            this.imgFotos.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgFotos.ImageStream")));
            this.imgFotos.TransparentColor = System.Drawing.Color.Transparent;
            this.imgFotos.Images.SetKeyName(0, "bateries.JPG");
            this.imgFotos.Images.SetKeyName(1, "camera.JPG");
            this.imgFotos.Images.SetKeyName(2, "computer.JPG");
            this.imgFotos.Images.SetKeyName(3, "computergame.JPG");
            this.imgFotos.Images.SetKeyName(4, "headphones.JPG");
            this.imgFotos.Images.SetKeyName(5, "internet.JPG");
            this.imgFotos.Images.SetKeyName(6, "keyboard.JPG");
            this.imgFotos.Images.SetKeyName(7, "webcam.JPG");
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.BackColor = System.Drawing.Color.OrangeRed;
            this.btnSiguiente.Location = new System.Drawing.Point(324, 360);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(82, 34);
            this.btnSiguiente.TabIndex = 5;
            this.btnSiguiente.Text = "Next";
            this.btnSiguiente.UseVisualStyleBackColor = false;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // imgFotos2
            // 
            this.imgFotos2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgFotos2.ImageStream")));
            this.imgFotos2.TransparentColor = System.Drawing.Color.Transparent;
            this.imgFotos2.Images.SetKeyName(0, "batteries2.JPG");
            this.imgFotos2.Images.SetKeyName(1, "camera2.JPG");
            this.imgFotos2.Images.SetKeyName(2, "computer2.JPG");
            this.imgFotos2.Images.SetKeyName(3, "computergame2.JPG");
            this.imgFotos2.Images.SetKeyName(4, "headphones2.JPG");
            this.imgFotos2.Images.SetKeyName(5, "internet2.JPG");
            this.imgFotos2.Images.SetKeyName(6, "keyboard2.JPG");
            this.imgFotos2.Images.SetKeyName(7, "webcam2.JPG");
            // 
            // imgFotos3
            // 
            this.imgFotos3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgFotos3.ImageStream")));
            this.imgFotos3.TransparentColor = System.Drawing.Color.Transparent;
            this.imgFotos3.Images.SetKeyName(0, "microhone.JPG");
            this.imgFotos3.Images.SetKeyName(1, "mobile.JPG");
            this.imgFotos3.Images.SetKeyName(2, "mouse.JPG");
            this.imgFotos3.Images.SetKeyName(3, "plug.JPG");
            this.imgFotos3.Images.SetKeyName(4, "speakers.JPG");
            this.imgFotos3.Images.SetKeyName(5, "switch.JPG");
            this.imgFotos3.Images.SetKeyName(6, "tablet.JPG");
            this.imgFotos3.Images.SetKeyName(7, "torch.JPG");
            // 
            // img4
            // 
            this.img4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("img4.ImageStream")));
            this.img4.TransparentColor = System.Drawing.Color.Transparent;
            this.img4.Images.SetKeyName(0, "microhone2.JPG");
            this.img4.Images.SetKeyName(1, "mobile2.JPG");
            this.img4.Images.SetKeyName(2, "mouse2.JPG");
            this.img4.Images.SetKeyName(3, "plug2.JPG");
            this.img4.Images.SetKeyName(4, "speakers2.JPG");
            this.img4.Images.SetKeyName(5, "switch2.JPG");
            this.img4.Images.SetKeyName(6, "tablet2.JPG");
            this.img4.Images.SetKeyName(7, "torch2.JPG");
            // 
            // btnReproducir1
            // 
            this.btnReproducir1.BackColor = System.Drawing.Color.Transparent;
            this.btnReproducir1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReproducir1.Image = ((System.Drawing.Image)(resources.GetObject("btnReproducir1.Image")));
            this.btnReproducir1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReproducir1.Location = new System.Drawing.Point(183, 53);
            this.btnReproducir1.Name = "btnReproducir1";
            this.btnReproducir1.Size = new System.Drawing.Size(78, 75);
            this.btnReproducir1.TabIndex = 9;
            this.btnReproducir1.UseVisualStyleBackColor = false;
            this.btnReproducir1.Click += new System.EventHandler(this.btnReproducir1_Click);
            // 
            // listimg1
            // 
            this.listimg1.BackColor = System.Drawing.Color.Transparent;
            this.listimg1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.listimg1.ImageIndex = 0;
            this.listimg1.ImageList = this.imgFotos;
            this.listimg1.Location = new System.Drawing.Point(46, 9);
            this.listimg1.Name = "listimg1";
            this.listimg1.Size = new System.Drawing.Size(90, 154);
            this.listimg1.TabIndex = 8;
            // 
            // listimg4
            // 
            this.listimg4.BackColor = System.Drawing.Color.Transparent;
            this.listimg4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.listimg4.ImageIndex = 0;
            this.listimg4.ImageList = this.img4;
            this.listimg4.Location = new System.Drawing.Point(290, 173);
            this.listimg4.Name = "listimg4";
            this.listimg4.Size = new System.Drawing.Size(130, 154);
            this.listimg4.TabIndex = 7;
            // 
            // listimg3
            // 
            this.listimg3.BackColor = System.Drawing.Color.Transparent;
            this.listimg3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.listimg3.ImageIndex = 0;
            this.listimg3.ImageList = this.imgFotos3;
            this.listimg3.Location = new System.Drawing.Point(46, 176);
            this.listimg3.Name = "listimg3";
            this.listimg3.Size = new System.Drawing.Size(90, 154);
            this.listimg3.TabIndex = 6;
            // 
            // listimg2
            // 
            this.listimg2.BackColor = System.Drawing.Color.Transparent;
            this.listimg2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.listimg2.ImageIndex = 0;
            this.listimg2.ImageList = this.imgFotos2;
            this.listimg2.Location = new System.Drawing.Point(300, 9);
            this.listimg2.Name = "listimg2";
            this.listimg2.Size = new System.Drawing.Size(106, 154);
            this.listimg2.TabIndex = 1;
            this.listimg2.Click += new System.EventHandler(this.listimg2_Click);
            // 
            // btnReproducir2
            // 
            this.btnReproducir2.BackColor = System.Drawing.Color.Transparent;
            this.btnReproducir2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReproducir2.Image = ((System.Drawing.Image)(resources.GetObject("btnReproducir2.Image")));
            this.btnReproducir2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReproducir2.Location = new System.Drawing.Point(183, 217);
            this.btnReproducir2.Name = "btnReproducir2";
            this.btnReproducir2.Size = new System.Drawing.Size(78, 75);
            this.btnReproducir2.TabIndex = 10;
            this.btnReproducir2.UseVisualStyleBackColor = false;
            this.btnReproducir2.Click += new System.EventHandler(this.btnReproducir2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(186, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 32);
            this.label1.TabIndex = 11;
            this.label1.Text = "Listen";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(186, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 32);
            this.label2.TabIndex = 12;
            this.label2.Text = "Listen";
            // 
            // button1
            // 
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(183, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 75);
            this.button1.TabIndex = 9;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(183, 217);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(78, 75);
            this.button2.TabIndex = 10;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnModulos
            // 
            this.btnModulos.BackColor = System.Drawing.Color.OrangeRed;
            this.btnModulos.Location = new System.Drawing.Point(183, 360);
            this.btnModulos.Name = "btnModulos";
            this.btnModulos.Size = new System.Drawing.Size(82, 34);
            this.btnModulos.TabIndex = 13;
            this.btnModulos.Text = "Modules";
            this.btnModulos.UseVisualStyleBackColor = false;
            this.btnModulos.Click += new System.EventHandler(this.btnModulos_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.OrangeRed;
            this.btnBack.Location = new System.Drawing.Point(54, 360);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(82, 34);
            this.btnBack.TabIndex = 14;
            this.btnBack.Text = "Previous";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // txtValidacion
            // 
            this.txtValidacion.AutoSize = true;
            this.txtValidacion.Location = new System.Drawing.Point(445, 9);
            this.txtValidacion.Name = "txtValidacion";
            this.txtValidacion.Size = new System.Drawing.Size(0, 13);
            this.txtValidacion.TabIndex = 15;
            // 
            // Learn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProyectoFinal2.Properties.Resources.fondo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(457, 448);
            this.Controls.Add(this.txtValidacion);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnModulos);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReproducir2);
            this.Controls.Add(this.btnReproducir1);
            this.Controls.Add(this.listimg1);
            this.Controls.Add(this.listimg4);
            this.Controls.Add(this.listimg3);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.listimg2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Learn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Learn";
            this.Load += new System.EventHandler(this.Learn_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imgFotos;
        private System.Windows.Forms.Label listimg2;
        private System.Windows.Forms.ImageList imgFotos2;
        private System.Windows.Forms.ImageList imgFotos3;
        private System.Windows.Forms.ImageList img4;
        private System.Windows.Forms.Label listimg3;
        private System.Windows.Forms.Label listimg4;
        private System.Windows.Forms.Label listimg1;
        private System.Windows.Forms.Button btnReproducir1;
        private System.Windows.Forms.Button btnReproducir2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnModulos;
        private System.Windows.Forms.Button btnBack;
        public System.Windows.Forms.Label txtValidacion;
        public System.Windows.Forms.Button btnSiguiente;
    }
}